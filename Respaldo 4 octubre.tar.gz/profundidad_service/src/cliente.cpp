#include "ros/ros.h"
#include "std_msgs/String.h"
#include <stdlib.h>
#include "rcnn_live_detector/Prediction.h"
#include "rcnn_live_detector/PredictionsList.h"
#include "profundidad_service/profundidadServer.h"
#include "profundidad_service/distance_msg.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include "ros/package.h"
#include <geometry_msgs/Point.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud2.h>
#include <limits>
#include <image_transport/image_transport.h>
#include <opencv/cv.h>
#include <image_geometry/pinhole_camera_model.h>
#include <tf/transform_listener.h>
#include <boost/foreach.hpp>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>

//NODOS
ros::Subscriber rgbdimage_sub_;
ros::ServiceClient client;
ros::Publisher image_pub_;

//Manejo de nodos para ROS
boost::shared_ptr<ros::NodeHandle> nh_ptr_;

//Paths
const std::string RECEIVE_IMG_TOPIC_NAME = "/cv_camera/image_raw_th";///cv_camera/image_raw_th


void imagenCallback(const sensor_msgs::ImageConstPtr& in_image)
{
 
  ROS_INFO("Received Image.");  
 

  //Etapa de envío
  rcnn_live_detector::Prediction prediccion1;

  prediccion1.label="gato";
  prediccion1.score=0.1616f;
  std::vector<double> boundingbox1;
  boundingbox1.push_back(291);
  boundingbox1.push_back(172);
  boundingbox1.push_back(372);
  boundingbox1.push_back(269);
  prediccion1.bbox=boundingbox1;


  /*
  rcnn_live_detector::Prediction prediccion2;

  prediccion1.label="perro";
  prediccion1.score=0.4040f;
  std::vector<double> boundingbox2;
  boundingbox2.push_back(274);
  boundingbox2.push_back(265);
  boundingbox2.push_back(370);
  boundingbox2.push_back(370);
  prediccion2.bbox=boundingbox2;
  */

  rcnn_live_detector::PredictionsList pList;
  pList.n=1;
  std::vector<rcnn_live_detector::Prediction> vectorPredictions;
  vectorPredictions.push_back(prediccion1);
  //vectorPredictions.push_back(prediccion2);

  pList.predictions=vectorPredictions;


  //Etapa llamado al servicio
  profundidad_service::profundidadServer llamado_a_servicio;
  llamado_a_servicio.request.image = *in_image;
  llamado_a_servicio.request.tags = pList;

  if (client.call(llamado_a_servicio))
    {
      std::vector<profundidad_service::distance_msg> respuesta_de_servicio = llamado_a_servicio.response.distanceslist;
      cv_bridge::CvImagePtr imagenDeServicio = cv_bridge::toCvCopy(llamado_a_servicio.response.imageRespuestaDeServicio, sensor_msgs::image_encodings::TYPE_32FC1);
       
      
 

      image_pub_.publish(imagenDeServicio);

      for (int i=0; i<respuesta_de_servicio.size(); ++i){
              std::cout << "Distancia: " << respuesta_de_servicio.at(i).distance << std::endl;
            }
    }


    else{
        std::cout <<"Failed to call a service" <<std::endl;
      }


 





}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "cliente_depth");
  ROS_INFO("Inicio del Nodo: cliente_depth");  
  

  nh_ptr_ = boost::make_shared<ros::NodeHandle>();
  rgbdimage_sub_ = nh_ptr_->subscribe<sensor_msgs::Image>(RECEIVE_IMG_TOPIC_NAME, 1, imagenCallback);
  client = nh_ptr_->serviceClient<profundidad_service::profundidadServer>("depth_Service");
  image_pub_ = nh_ptr_->advertise<sensor_msgs::Image>("/objectDetected", 1);



  ros::spin();

  return 0;
}