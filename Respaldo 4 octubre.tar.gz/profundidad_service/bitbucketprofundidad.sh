 #!/bin/bash         

echo "Push a Bitbucket"
git add --all
git commit -m "Tiempo: $(date +%d-%b-%H_%M)"
git push origin programaOrdenadoProfundidad

echo "Push finalizado"

