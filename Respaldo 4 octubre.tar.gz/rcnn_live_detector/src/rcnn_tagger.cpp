#include "ros/ros.h"
#include "std_msgs/String.h"
#include <stdlib.h>
#include "rcnn_live_detector/Prediction.h"
#include "rcnn_live_detector/PredictionsList.h"
#include "rcnn_live_detector/imageTagger.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include "ros/package.h"
#include <geometry_msgs/Point.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud2.h>
#include <limits>
#include <image_transport/image_transport.h>
#include <opencv/cv.h>
#include <image_geometry/pinhole_camera_model.h>
#include <tf/transform_listener.h>
#include <boost/foreach.hpp>
#include <sensor_msgs/image_encodings.h>


ros::Subscriber tag_sub;
ros::Publisher image_pub_;
ros::Publisher centinel_pub_;
ros::Subscriber rgbdimage_sub_;
boost::shared_ptr<ros::NodeHandle> nh_ptr_;
ros::Subscriber camera_sub;
ros::ServiceClient client;

//const std::string RECEIVE_IMG_TOPIC_NAME = "/cv_camera/image_raw_th";
const std::string RECEIVE_IMG_TOPIC_NAME = "/rgb/rect_out";//"/rgb/rect_out";

void rgbdImageCallback(const sensor_msgs::ImageConstPtr &in_image)
{
  //rgbdimage_sub_.shutdown();
  ROS_INFO("Received Image.");

  rcnn_live_detector::imageTagger imgService;
  imgService.request.image = *in_image;


  if (client.call(imgService))
  {
    //std::cout << imgService.response.tag << std::endl;
    ROS_INFO("Received information from rcnn_tagger node.");

    int n = imgService.response.tags.n;
    std::vector<rcnn_live_detector::Prediction> listOfPredictions = imgService.response.tags.predictions;/*declara 
                                                                                                          un vector de objetos
                                                                                                          tipo Prediction*/

    //
    cv_bridge::CvImageConstPtr imgOriginal = cv_bridge::toCvShare(in_image, sensor_msgs::image_encodings::BGR8);
    cv::Mat imageCV = imgOriginal->image;

    std::stringstream ss;
    ss << "Cantidad de Predicciones: " << n << std::endl;
    for (int i = 0; i < listOfPredictions.size(); ++i)
    {
      std::string tag = listOfPredictions.at(i).label;
      float score = listOfPredictions.at(i).score;
      std::vector<double> bbox = listOfPredictions.at(i).bbox;
      ss << "\nLabel: " << tag << std::endl
         << "Confidence: " << score << std::endl
         << "X1: " << bbox.at(0) << std::endl
         << "Y1: " << bbox.at(1) << std::endl
         << "X2: " << bbox.at(2) << std::endl
         << "Y2: " << bbox.at(3) << std::endl;
      cv::rectangle(imageCV, cv::Point(bbox.at(0), bbox.at(1)), cv::Point(bbox.at(2), bbox.at(3)), cv::Scalar(0,0,255), 1, 8);

    }
    std::cout << ss.str();

    std_msgs::String msg;
    msg.data = ss.str();
    centinel_pub_.publish(msg);

    //cv::imwrite("/home/jcarlos2289/catkin_ws/results/rcnn_live_detector/img.jpg", imageCV);
    sensor_msgs::ImagePtr imagenComoMensaje = cv_bridge::CvImage(std_msgs::Header(), "bgr8", imageCV).toImageMsg();
    image_pub_.publish(imagenComoMensaje);
  }
  else
  {
    ROS_ERROR("Failed to call service tag_Service");
    //return 1;
  }
}




int main(int argc, char **argv)
{

  ros::init(argc, argv, "rcnn_tagger");

  nh_ptr_ = boost::make_shared<ros::NodeHandle>();

  //this will publish the msg for the reader/visualzer node
  //cluster_pub_ = nh_ptr_->advertise<rcnn_live_detector::PredictionsList>("/cluster_data_topic", 1, connectCallback, disconnectCallback);

  //this receive the msg with the bounding box and the identified labels
  //tag_sub = nh_ptr_->subscribe("/identified_tags", 1, tag_cb);

  //this will send the order to beggin with the classification

  centinel_pub_ = nh_ptr_->advertise<std_msgs::String>("/centinela", 1);
  image_pub_ = nh_ptr_->advertise<sensor_msgs::Image>("/objectDetected", 1);
  client = nh_ptr_->serviceClient<rcnn_live_detector::imageTagger>("tag_Service");
  rgbdimage_sub_ = nh_ptr_->subscribe<sensor_msgs::Image>(RECEIVE_IMG_TOPIC_NAME, 1, rgbdImageCallback);

  ros::spin();

  return 0;
}