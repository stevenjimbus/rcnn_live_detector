#!/usr/bin/env python
#jcarlos 2289
# 21/06/2016

import rospy
from std_msgs.msg import String
from subprocess import call
from rcnn_live_detector.msg import Prediction
from rcnn_live_detector.msg import PredictionsList
import json


#callback function that waits until the centinel topic recibe an msg to beggin the classification
def centinel_cb(data):
    print('Beggining of Tagging Procedure.')
    pub = rospy.Publisher('identified_tags', PredictionsList, queue_size=10)
    #execute the external pycaffe classifier
    call(["/home/jcarlos2289/catkin_ws/src/rcnn_live_detector/src/pyCaffeDemo.sh", "/home/jcarlos2289/catkin_ws/results/rcnn_live_detector/imgToTag.jpg"])
    print('Reading JSON file.')
    #read the json file from the results directory
    jData = []
    with open('/home/jcarlos2289/catkin_ws/results/rcnn_live_detector/proposal.json') as json_data:
        for line in json_data:
            jData.append(json.loads(line))
    
    #prepare the msg in order to publish in the topic
    msgList = PredictionsList()
    msgList.n = len(jData[0]['proposals'][0])
    lista = []

    #walk through the json file and to get the different identified labels
    for i in jData[0]['proposals'][0]:
        boundingBox = []

        msg = Prediction()
        msg.label = i['tag']
        msg.score = float(i['score'])
        
        boundingBox.append(float(i['bounding-box'][0]['x1']))
        boundingBox.append(float(i['bounding-box'][0]['y1']))
        boundingBox.append(float(i['bounding-box'][0]['x2']))
        boundingBox.append(float(i['bounding-box'][0]['y2']))

        msg.bbox = boundingBox
        lista.append(msg)
    
    msgList.predictions = lista

    #publish the predictions list to the topic
    pub.publish(msgList)


def classifier_server():
    #pub = rospy.Publisher('chatter', String, queue_size=10)
    
    rospy.init_node('classifier_server', anonymous=True)
    rospy.Subscriber('centinel', String, centinel_cb)
    #rate = rospy.Rate(10) # 10hz
    rospy.spin()
    #while not rospy.is_shutdown():
      #rate.sleep()

if __name__ == '__main__':
    try:
        classifier_server()
    except rospy.ROSInterruptException:
        pass
